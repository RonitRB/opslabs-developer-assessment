"""YouTube metadata collector."""
